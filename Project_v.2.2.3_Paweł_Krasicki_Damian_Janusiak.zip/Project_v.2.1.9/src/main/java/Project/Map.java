package Project;
import java.util.*;

/**
 * Responsible for creating the map
 */

public class Map {
   static char[][] screenMap = new char[Console.MapSize][Console.MapSize];


   public  void mapCreator() {
    Random rand = new Random();
    for (int i =0 ; i<Console.MapSize; i++) {
        for (int j= 0 ; j< Console.MapSize; j++) {
            screenMap[i][j]=' ';
        }
    }
    int x,y;
    for (int i=0; i<Console.NumberOfPassive;i++) {
        do {
            x = rand.nextInt(Console.MapSize);
            y = rand.nextInt(Console.MapSize);
            } while ( screenMap[x][y]!=' ');
        Console.Obj.add(new AISimple(x,y));
        screenMap[x][y]='P';
    }
    for (int i=0; i<Console.AmountOfFood ; i++) {
      putFood();
    };
/**
 * Responsible for adding food to the map
 */

}
    public   void  putFood() {

           int x, y;
           do {
               Random rand = new Random();
               x = rand.nextInt(Console.MapSize);
               y = rand.nextInt(Console.MapSize);
           } while (Map.screenMap[x][y] != ' ');
           Console.Foods.add(new Food(x, y));
           Map.screenMap[x][y] = 'F';

    }
}
