package Project;

/**
 * Class responsible for eating and finding food by AI objects
 */
public class AIFoods implements Positions{
    /**
     * Responsible for looking for the food in a larger area.
     * @param AI - AI object
     */

    public  void aggressiveSearchingFood(AISimple AI) {
        int x = 0,y=0;
        int index= -1;
        int aggressiveRange = 3;
        for ( int i =0 ; i <aggressiveRange ; i++ ) {
            for ( int j=0; j <aggressiveRange ; j++) {
                if ( (AI.x-1+i<Console.MapSize) && (AI.y-1+j<Console.MapSize)&& (AI.x-1+i>0) && (AI.y-1+j>0))
                    if (Map.screenMap[AI.x-1+i][AI.y-1+j]=='F')
                    { x=AI.x-1+i;y=AI.y-1+j;break;}
                Food found= new Food(-1,-1);
                index = found.indexSearching(AI.x-1+i,AI.y-1+j);
        double foodValue =found.FoodValue(found,AI);
       if (index>-1) {AI.eatingFood(AI,foodValue,index);} }}
        }
    /**
     * Responsible for searching food on the map
     * @param AI - AI object
     */
    public  void searchingFood(AISimple AI) {
        int i,j ;
        int index =-1;
        int simpleRange = 2;
        for ( i =0 ; i <simpleRange ; i++ ) {
            for ( j=0; j <simpleRange ; j++) {
                if ( (AI.x-1+i<Console.MapSize) && (AI.y-1+j<Console.MapSize) && (AI.x-1+i>0) && (AI.y-1+j>0)) {
                    if (Map.screenMap[AI.x-1+i][AI.y-1+j]=='F') {
                        Food found= new Food(-1,-1);
                        index = found.indexSearching(AI.x-1+i,AI.y-1+j);
                        double foodValue =found.FoodValue(found,AI);
                        if (index >-1) {AI.eatingFood(AI,foodValue,index); }}}}}

    }

    /**
     * Responsible for eating food by the object
     * @param AI - object
     * @param foodValue - food value
     * @param index - food index
     */
    public  void eatingFood(AISimple AI, double foodValue,int  index) {
        AI.EnergyLVL += foodValue;
        if (index > 0) {
            Food food = Console.Foods.get(index);
            Map.screenMap[food.x][food.y] = ' ';
            if (index != -7) Console.Foods.remove(index);
                Console.AmountOfFood--;

        }
    }

    /**
     * finding Objects ID
     * @param a - coordinates
     * @param b - coordinates
     * @return Objects ID if ID == -1 object doesn't exist
     */
    public int indexSearching(int a, int b) {
        for (int i =0 ; i< Console.Obj.size();i++) {
            AISimple searching = Console.Obj.get(i);
            if ((a== searching.x) && (b== searching.y)) return i;
        } return -1;
    }

}
