package Project;
import java.lang.System;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import static Project.Map.screenMap;

/**
 * Responsible for communication with the client and simulation operation.
 * @param NumberOfAggressive - Number of currently aggressive objects on the map
 * @param NumberOfPassive - Number of currently passive objects the on map
 * @param AmountOfFood - Amount of current food on the map
 * @param MapSize - Size of the map
 * @param Obj - List of all AI objects
 * @param Foods - List of all Food on the map
 */

public class Console implements MapInfo{
    public static int NumberOfAggressive=0;
    public static int NumberOfPassive=0;
    public  static double AmountOfFood=0;
    public static int MapSize;
    static List<AISimple> Obj= new LinkedList<>();
    public  static List<Food> Foods= new ArrayList<>();
    /**
     * Communication with client
     */
    public static void main(String[] args ) throws InterruptedException {
        boolean format = false;
        Scanner scan = new Scanner(System.in);
        System.out.println("Set the Number of AI Objects:");
        while(!scan.hasNextInt() || (NumberOfPassive = scan.nextInt()) <= 0) {
            System.out.println("There are no AI Objects! Please set the Number of Them:");
            scan = new Scanner(System.in);
        }
        System.out.println("Set the Amount of Food:");
        while(!scan.hasNextInt() || (AmountOfFood = scan.nextInt()) <= 0) {
            System.out.println("There are wrong AmountOfFood value! Please set the Number of Them:");
            scan = new Scanner(System.in);
        }
        System.out.println("Set the Map size (one side) :");
        while(!scan.hasNextInt() || (MapSize = scan.nextInt()) < (Console.AmountOfFood+Console.NumberOfPassive)/Console.MapSize || MapSize <= 0){
            System.out.println("Map size is too small! Please enter a larger dimension");
            scan = new Scanner(System.in);
        }
      Console simulation= new Console(MapSize,NumberOfPassive,AmountOfFood);
    }

    /**
     * Working simulation
     * @param MapSize - Map size
     * @param AINumber - Number of all AI object
     * @param AmountOfFood - Amount of initial food on the map
     */
    public Console(int  MapSize , int AINumber, double AmountOfFood) throws InterruptedException {
    Map map = new Map();
    map.mapCreator();
    int numberOfTurns = 100;
    for (int j =0 ; j<numberOfTurns; j++) {

        mapView();
        for (int i = 0; i < (Obj.size()); i++) {
            AISimple AI = Obj.get(i);
            Map.screenMap = AI.move(AI);
            AI.energyLVL(AI);
            AI.isAggressive(AI);
            if (AI.aggressiveness==true) {AI.aggressiveSearchingFood(AI);} else
           {AI.searchingFood(AI);}
            }

      if (MapSize*MapSize<Obj.size()+Foods.size())  map.putFood();

    }}

    public void mapView() {
        for (int i=0;i<Console.MapSize; i++) {
            for (int j=0;j<Console.MapSize;j++) {
                System.out.print((screenMap[i][j]));
            } System.out.println();
        }
        System.out.println(" Number of Passive :" +Console.NumberOfPassive + " Number of Aggressive :" + Console.NumberOfAggressive + " Amount of Food :" + Console.Foods.size());
        System.out.println("==============================================================");
    }


}
