package Project;
/**
 * Responsible for displaying the map and information
 */

import static Project.Map.screenMap;
public interface MapInfo {

  void mapView();
}
