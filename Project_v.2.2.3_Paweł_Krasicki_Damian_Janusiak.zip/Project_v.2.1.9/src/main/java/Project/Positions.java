package Project;

/**
 * Responsible for finding objects and food ID using only coordinates
 * @param a , b coordinates
 */
public interface Positions {
    /**
     * Finding Object or food ID
     * @param a - coordinates
     * @param b - coordinates
     * @return food ID. if id == -1 there is no food there
     */
    int indexSearching(int a, int b) ;


}
