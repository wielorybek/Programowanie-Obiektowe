package Project;

import java.util.Random;

/**
 * Class responsible for creating and searching food and setting foodValue
 */
public class Food implements Positions{
    int x,y;
    public Food( int a, int b){
     if ((x<0) && (y<0))   x=a;y=b;
    }

    /**
     * Finding food ID
     * @param a - coordinates
     * @param b - coordinates
     * @return ID If ID == -1 food doesn't exist
     */
    public int indexSearching(int a, int b) {
        for (int i =0 ; i< Console.Foods.size();i++) {
            Food searching = Console.Foods.get(i);
            if ((searching.x==a)  && (searching.y==b)) return i;
        }return -1;
    }

    /**
     * Responsible for setting food value for objects
     * @param food food
     * @param AIP AI Objects that have found food
     * @return food value
     */
    public  double FoodValue(Food food, AISimple AIP) {
        int x = 0, y = 0, corners = 2;
        for (int j = 0; j < corners; j++) {
            for (int i = 0; i < corners; i++) {
                if ((food.x-1+i>0) && (food.x-1+i<Console.MapSize) && (food.y-1+j>0) && (food.y-1+j<Console.MapSize))
                    if (Map.screenMap[food.x - 1 + i][food.y - 1 + j] == 'P') {
                        x = food.x - 1 + i;
                        y = food.y - 1 + j;
                        if ((x!=AIP.x) || (y!=AIP.y)) {
                            AISimple secondAI = Console.Obj.get(indexSearching(x, y));
                            secondAI.eatingFood(secondAI,5,-7);
                        }
                    }
                return 5;
            }
        }

        for (int i = 0; i < corners; i++) {
            for (int j = 0; j < corners; j++) {
                if (Map.screenMap[food.x - 1 + i][food.y - 1 + j] == 'A') {
                    x = food.x - 1 + i;
                    y = food.y - 1 + j;
                    AISimple secondAI = Console.Obj.get(indexSearching(x, y));
                }
                return 0;
            }
        }

        return 10;
    }
    }
