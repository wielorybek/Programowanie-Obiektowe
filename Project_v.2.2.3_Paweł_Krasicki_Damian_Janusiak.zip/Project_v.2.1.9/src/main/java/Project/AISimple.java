package Project;
/**
 * Responsible for randomly moving the object around the map ( #move), searching (#searchingFood) and eating (#eatingFood) food by objects.
        Class checks if the object is aggressive (#isAgressive) and decreases or recovers EnergyLVL (#EnergyLVL)
        * @param AI - an object, in our case a human
        * @param foodValue - current food value for the object
        * @param x , y - coordinates of the object on the map.
        */

import java.util.Random;
public class AISimple extends AIFoods {
    protected double EnergyLVL=70;
    public boolean aggressiveness=false;
    protected  char kind = 'P';
    int x,y;

    /**
     * Constructor of AI Objects
     * @param a - Coordinates on the map
     * @param b - Coordinates on the map
     */
    public AISimple(int a , int b) {
        x=a;y=b;
    aggressiveness=false;
    double EnergyLVL;
    char kind;
    }

    /**
     * Moving objects around the map
     * @param AI - AI object
     * @return return map with changes
     */
    public  char[][] move(AISimple AI) {
        Random rand = new Random();
        int trials =0;
        Map.screenMap[AI.x][AI.y]=' ';
        int x=0,y=0;
        int a = AI.x;
        int b = AI.y;


        int movement = rand.nextInt(8);
        if (movement == 0) {
            x = AI.x + 1;
            y = AI.y + 1;
        }
        if (movement == 1) {
            x = AI.x + 1;
            y = AI.y + 1;
        }
        if (movement == 2) {
            x = AI.x ;
            y = AI.y +1;
        }
        if (movement == 3) {
            x = AI.x - 1;
            y = AI.y + 1;
        }
        if (movement == 4) {
            x = AI.x -1;
            y = AI.y ;
        }
        if (movement == 5) {
            x = AI.x - 1;
            y = AI.y - 1;
        }
        if (movement == 6) {
            x = AI.x;
            y = AI.y - 1;
        } ;
        if (movement == 7) {
            x = AI.x +1;
            y = AI.y - 1;
        }
        if (movement == 8) {
            x = AI.x + 1;
            y = AI.y ;
        } ;
        if ((x<Console.MapSize) && (x>0) && (y<Console.MapSize) && (y>0) && (Map.screenMap[x][y]==' ')) {AI.x=x;AI.y=y;}
        Map.screenMap[AI.x][AI.y] = AI.kind;
        return Map.screenMap;
        }





    /**
     * Testing whether the object should be aggressive
     * @param AI - object
     */

    public  void isAggressive(AISimple AI) {
        if ((AI.EnergyLVL<35) && (AI.aggressiveness==false)) {AI.aggressiveness=true;
        AI.kind='A';
        Console.NumberOfAggressive++;
        Console.NumberOfPassive--;
        }
        if (AI.EnergyLVL>=35 && AI.aggressiveness==true) {AI.aggressiveness = false;
            AI.kind='P';
            Console.NumberOfAggressive--;
            Console.NumberOfPassive++;
        }
    }

    /**
     * Decreasing energyLVL
     * @param AI - object
     */
    public  void energyLVL(AISimple AI) {
        AI.EnergyLVL-=2.5;}




}


