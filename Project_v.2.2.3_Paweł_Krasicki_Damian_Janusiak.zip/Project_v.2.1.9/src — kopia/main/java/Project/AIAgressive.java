package Project;

public class AIAgressive {
    public void moremove() {}
}
