package Project;

public class Food extends AISimple {
    int x,y;
    public Food( int a, int b){
        super(a,b);
    }
    public void AnyoneNear ()
    {

    }
}
