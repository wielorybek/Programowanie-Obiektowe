package Project;

public interface IsCollectable {
}
