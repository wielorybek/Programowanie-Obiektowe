package Project;

import static Project.Mapa.smap;
public interface MapInfo {
    static void mapview() {
        for (int i=0;i<Console.Mapsize; i++) {
        for (int j=0;j<Console.Mapsize;j++) {
      System.out.print((smap[i][j]));
        } System.out.println();
        }

    }

}
