package Project;
import java.lang.System;
import java.util.Scanner;
public class Console implements MapInfo{
    public static int NumberofAgressive=0;
    public static int NumberofPassive=0;
    public  static double AmountofFood=0;
    public static int Mapsize;
    public static void main(String[] args )
    { Scanner scan = new Scanner(System.in);
        System.out.println("Set Mapsize :");
        Mapsize= scan.nextInt();
        System.out.println("Set Number of AI Objects:");
        NumberofPassive= scan.nextInt();
        System.out.println("Set Amount of Food:");
        AmountofFood = scan.nextDouble();
        Simulation();
    }
    public static void Simulation(){
       Mapa.MapCreator(Mapsize, NumberofPassive,AmountofFood);
      MapInfo.mapview();
    }
}
