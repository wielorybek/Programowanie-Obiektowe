package Project;
import java.util.*;

public class Mapa {
   static char[][] smap = new char[Console.Mapsize][Console.Mapsize];
public static Map  MapCreator( int mapsize , int NumberofPassive, double AmountofFood) {

    Map<Arrays, AISimple> mapa = new HashMap<>();

    Random rand = new Random();
    int x,y;

    List<AISimple> PassiveObj= new LinkedList<>();
    PassiveObj.size();
    for (int i=0; i<NumberofPassive;i++) {
        do {
            x = rand.nextInt(mapsize);
            y = rand.nextInt(mapsize);
            } while (mapa.get(smap[x][y])!=null);
        PassiveObj.add(new AISimple(x,y));
        //mapa.put(smap[x][y], PassiveObj.get(i));
        smap[x][y]='O';
    }

    List<Food> Foods= new LinkedList<>();
    for (int i=0; i<AmountofFood ; i++) {  do {
        x = rand.nextInt(mapsize);
        y = rand.nextInt(mapsize);
    } while (mapa.get(smap[x][y])!=null);
    Foods.add(new Food(x,y));
        //mapa.put(smap[x][y], Foods.get(i));
    smap[x][y]='F';
    }

    return mapa; };
}
