package Project;

import java.util.Random;
public class AISimple {
    protected double defaultEnergyLVL=70;
    public boolean agressiveness=false;

    int x,y;
    public AISimple(int a , int b) {
        x=a;y=b;
    agressiveness=false;
    double EnergyLVL= defaultEnergyLVL;
    }
    public void move(AISimple AI) {
        Random rand = new Random();
        int movement= rand.nextInt(8);
        if (movement==1) { }
}}
